Module 4 — KPI & Dashboard Pack
- kpi-glossary.md
- nsm-input-tree-template.md
- dashboard_exec_template.csv
- dashboard_squad_template.csv
- dashboard_experiment_template.csv

Conseils :
1) Définissez la **NSM** et ses **inputs** (template NSM Tree).
2) Choisissez le **pattern de dashboard** (Exec ou Squad) et dupliquez le CSV dans Sheets/Excel.
3) Ajoutez **seuils** (vert/orange/rouge) et **owners** ; installez une **revue hebdo** (30’).
4) Suivez vos **expériences A/B** avec le template Experiment.
