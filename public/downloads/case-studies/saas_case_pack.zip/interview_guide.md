# Guide d'interview (10 questions)
1. Votre rôle et fréquence de RDV ?
2. Dernier RDV organisé : où avez-vous perdu du temps ?
3. Comment gérez-vous les no-shows ?
4. Intégrations indispensables (Outlook/Google, CRM, paiement) ?
5. Quel signal vous ferait payer la solution ?
6. Freins après inscription avant de publier un lien ?
7. Qu’attendez-vous dans les 24 premières heures (TTFV) ?
8. Succès à 7 jours ? à 30 jours ?
9. Cas où vous recommanderiez l’outil ?
10. Quel message/hook vous parle le plus ?
