# Sondage in-app (1 question + libre)
Question : Qu’est-ce qui vous bloque le plus pour planifier vos RDV ?
(a) Intégrations (Outlook/Google/CRM)
(b) No-shows
(c) Coordination à plusieurs interviewers
(d) Paiements/Pré-paiement
(e) Fuseaux horaires
(f) Autre : _____________

Champ libre : décrivez en une phrase votre blocage principal.
