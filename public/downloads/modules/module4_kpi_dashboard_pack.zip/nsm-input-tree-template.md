# Template — NSM Input Tree
NSM : _Utilisateurs activés / semaine_

Inputs (exemples) :
- Acquisition → CVR visite→signup
- Activation → Aha Rate, TTFV
- Rétention → D7/D30, Stickiness (DAU/MAU)
- Revenus → Free→Paid, ARPU
- Recommandations → Referrals/100, K-factor

Pour chaque input : 2–3 **leviers testables**, 1 **expérience** (hypothèse, KPI, critères).
